﻿using UnityEngine;


  public class PhysicsParamsContainer : MonoBehaviour {

    public PhysicsParams physicsParams;
  }

